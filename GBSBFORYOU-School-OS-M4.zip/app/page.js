'use client';
import {useEffect,useState} from 'react';
import './globals.css';

const initial={admissionNo:'',studentId:'',name:'',dob:'',gender:'',className:'',section:'',session:'',status:'Active',father:'',mother:'',guardianPhone:'',address:'',previousSchool:'',notes:''};

export default function Page(){
 const [form,setForm]=useState(initial); const [saved,setSaved]=useState(false);
 const [students,setStudents]=useState([]);
 useEffect(()=>{try{setStudents(JSON.parse(localStorage.getItem('m4_students')||'[]'))}catch{}},[]);
 function change(k,v){setForm({...form,[k]:v})}
 function save(){
   const id=form.studentId||('STU-'+Date.now().toString().slice(-8));
   const record={...form,studentId:id,updatedAt:new Date().toISOString()};
   const next=[...students.filter(x=>x.studentId!==id),record];
   localStorage.setItem('m4_students',JSON.stringify(next)); setStudents(next); setForm(record);
   setSaved(true); setTimeout(()=>setSaved(false),1600);
 }
 function clear(){setForm(initial)}
 return <main>
  <header><div><div className="eyebrow">GBSBFORYOU SCHOOL/OS · M4</div><h1>Student Information System</h1><p>एक संस्था के छात्र का एकीकृत, संस्थागत और scope-controlled मूल रिकॉर्ड।</p></div><span className="badge">Institution Scoped</span></header>
  <section className="hero">
   <div><small>MODULE</small><strong>Student Master Record</strong></div><div><small>DATA OWNER</small><strong>Institution</strong></div><div><small>SOURCE OF TRUTH</small><strong>Student Identity</strong></div><div><small>ACCESS</small><strong>Authorized Scope</strong></div>
  </section>
  <section className="card">
   <h2>Student Master Record</h2>
   <div className="formgrid">
    <Field label="Admission No." value={form.admissionNo} onChange={v=>change('admissionNo',v)}/>
    <Field label="Student ID" value={form.studentId} onChange={v=>change('studentId',v)} placeholder="खाली छोड़ें तो स्वतः बनेगा"/>
    <Field label="Student Name *" value={form.name} onChange={v=>change('name',v)}/>
    <Field label="Date of Birth" type="date" value={form.dob} onChange={v=>change('dob',v)}/>
    <Select label="Gender" value={form.gender} onChange={v=>change('gender',v)} options={['','Male','Female','Other','Not specified']}/>
    <Select label="Status" value={form.status} onChange={v=>change('status',v)} options={['Active','Inactive','Transferred','Alumni','Withdrawn']}/>
    <Field label="Class" value={form.className} onChange={v=>change('className',v)}/>
    <Field label="Section" value={form.section} onChange={v=>change('section',v)}/>
    <Field label="Academic Session" value={form.session} onChange={v=>change('session',v)} placeholder="उदा. 2026–27"/>
   </div>
  </section>
  <section className="grid two">
   <article className="card"><h2>Family & Contact</h2>
    <Field label="Father / Parent 1" value={form.father} onChange={v=>change('father',v)}/>
    <Field label="Mother / Parent 2" value={form.mother} onChange={v=>change('mother',v)}/>
    <Field label="Guardian Phone" value={form.guardianPhone} onChange={v=>change('guardianPhone',v)}/>
    <label>Address<textarea value={form.address} onChange={e=>change('address',e.target.value)}/></label>
   </article>
   <article className="card"><h2>Academic History</h2>
    <Field label="Previous School / Institution" value={form.previousSchool} onChange={v=>change('previousSchool',v)}/>
    <label>Notes<textarea value={form.notes} onChange={e=>change('notes',e.target.value)}/></label>
    <p className="note">Documents, attendance, fees, examinations और transport अपने-अपने domain modules में source-of-truth रहेंगे; यह record उनसे IDs के माध्यम से जुड़ेगा।</p>
   </article>
  </section>
  <section className="actions"><button onClick={save}>Save Student Record</button><button className="secondary" onClick={clear}>New Student</button>{saved&&<span className="success">रिकॉर्ड सुरक्षित ✓</span>}</section>
  <section className="card"><h2>Saved Student Records — Prototype</h2>
   {students.length===0?<p className="note">अभी कोई स्थानीय prototype record नहीं है।</p>:
   <div className="table"><div className="tr th"><span>Student</span><span>ID / Admission</span><span>Class</span><span>Status</span></div>
   {students.map(s=><div className="tr" key={s.studentId}><span>{s.name||'—'}</span><span>{s.studentId}<br/><small>{s.admissionNo||'—'}</small></span><span>{s.className||'—'} {s.section||''}</span><span>{s.status}</span></div>)}</div>}
  </section>
  <section className="card policy"><h2>M4 Data Governance</h2><ol>
   <li>Student record संस्था के tenant/scope से बंधा रहेगा।</li><li>Student ID अन्य modules के साथ linkage key का काम करेगा।</li>
   <li>एक संस्था का operational student data दूसरी संस्था को उपलब्ध नहीं होना चाहिए।</li>
   <li>AI student data पर केवल अधिकृत scope और policy के अनुसार काम करेगा।</li>
   <li>Production में server-side authorization, audit, database और secure document references अनिवार्य हैं।</li>
  </ol></section>
  <footer>GBSBFORYOU School/OS · M4 Foundation · Institution manages its own student data</footer>
 </main>
}

function Field({label,value,onChange,type='text',placeholder=''}){return <label>{label}<input type={type} value={value||''} placeholder={placeholder} onChange={e=>onChange(e.target.value)}/></label>}
function Select({label,value,onChange,options}){return <label>{label}<select value={value} onChange={e=>onChange(e.target.value)}>{options.map(o=><option key={o} value={o}>{o||'Select'}</option>)}</select></label>}