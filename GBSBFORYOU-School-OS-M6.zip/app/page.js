'use client';
import {useEffect,useState} from 'react';
import './globals.css';

const blank={classId:'',className:'',section:'A',program:'',stream:'',session:'2026–27',classTeacher:'',capacity:'40',status:'Active',notes:''};

export default function Page(){
 const [form,setForm]=useState(blank),[records,setRecords]=useState([]),[saved,setSaved]=useState(false);
 useEffect(()=>{try{setRecords(JSON.parse(localStorage.getItem('m6_class_sections')||'[]'))}catch{}},[]);
 const set=(k,v)=>setForm({...form,[k]:v});
 function save(){
   if(!form.className.trim())return;
   const id=form.classId||'CLS-'+Date.now().toString().slice(-8);
   const r={...form,classId:id,capacity:Number(form.capacity)||0,updatedAt:new Date().toISOString()};
   const next=[...records.filter(x=>x.classId!==id),r];
   localStorage.setItem('m6_class_sections',JSON.stringify(next));setRecords(next);setForm(r);
   setSaved(true);setTimeout(()=>setSaved(false),1600);
 }
 function edit(r){setForm(r)}
 return <main>
  <header><div><div className="eyebrow">GBSBFORYOU SCHOOL/OS · M6</div><h1>Class, Section & Academic Structure</h1><p>संस्था की कक्षा, section और academic hierarchy का structured foundation।</p></div><span className="badge">Scope Controlled</span></header>
  <section className="hero">
   <div><small>MODULE</small><strong>Academic Structure</strong></div><div><small>LINK</small><strong>M2 Session</strong></div><div><small>STUDENT</small><strong>M4 Student ID</strong></div><div><small>ACCESS</small><strong>Authorized Scope</strong></div>
  </section>
  <section className="card"><h2>Class / Section Record</h2>
   <div className="formgrid">
    <Field label="Structure ID" value={form.classId} onChange={v=>set('classId',v)} placeholder="खाली छोड़ें तो स्वतः बनेगा"/>
    <Field label="Class *" value={form.className} onChange={v=>set('className',v)} placeholder="उदा. Class 8"/>
    <Field label="Section" value={form.section} onChange={v=>set('section',v)} placeholder="A"/>
    <Field label="Academic Session" value={form.session} onChange={v=>set('session',v)}/>
    <Field label="Program / Course" value={form.program} onChange={v=>set('program',v)}/>
    <Field label="Stream" value={form.stream} onChange={v=>set('stream',v)} placeholder="उदा. Science"/>
    <Field label="Class Teacher" value={form.classTeacher} onChange={v=>set('classTeacher',v)}/>
    <Field label="Capacity" value={form.capacity} onChange={v=>set('capacity',v)} type="number"/>
    <Select label="Status" value={form.status} onChange={v=>set('status',v)} options={['Active','Inactive','Archived']}/>
   </div>
   <label>Notes<textarea value={form.notes||''} onChange={e=>set('notes',e.target.value)}/></label>
  </section>
  <section className="actions"><button onClick={save}>Save Class / Section</button><button className="secondary" onClick={()=>setForm(blank)}>New Structure</button>{saved&&<span className="success">संरचना सुरक्षित ✓</span>}</section>
  <section className="grid two">
   <article className="card"><h2>Academic Hierarchy</h2><div className="flow"><span>Session</span><i>→</i><span>Program</span><i>→</i><span>Class</span><i>→</i><span>Section</span><i>→</i><span>Student</span></div><p className="note">M4 student records इस structure से scoped linkage के माध्यम से जुड़ेंगे।</p></article>
   <article className="card"><h2>Operational Controls</h2><ul className="checks"><li>✓ Session-scoped structure</li><li>✓ Class/section status</li><li>✓ Capacity field</li><li>✓ Class teacher assignment</li><li>✓ Scope-based permissions</li><li>✓ Audit-ready changes</li></ul></article>
  </section>
  <section className="card"><h2>Saved Structures — Prototype</h2>
   {records.length===0?<p className="note">अभी कोई स्थानीय prototype structure नहीं है।</p>:
   <div className="table"><div className="tr th"><span>Class / Section</span><span>Session</span><span>Program / Stream</span><span>Teacher</span><span>Status</span><span></span></div>
   {records.map(r=><div className="tr" key={r.classId}><span><b>{r.className} — {r.section}</b><small>{r.classId}</small></span><span>{r.session}</span><span>{r.program||'—'} {r.stream?'/ '+r.stream:''}</span><span>{r.classTeacher||'—'}</span><span>{r.status}</span><button className="tiny" onClick={()=>edit(r)}>Edit</button></div>)}</div>}
  </section>
  <section className="card policy"><h2>M6 Governance Rules</h2><ol>
   <li>M2 Academic Session & Calendar से academic session linkage रहेगा।</li>
   <li>M6 class, section और academic structure का source-of-truth रहेगा।</li>
   <li>M4 Student Master Records class/section से linked रहेंगे, duplicate student identity नहीं बनेगी।</li>
   <li>M7 Subjects/Curriculum और M10 Timetable इस structure को संदर्भित करेंगे।</li>
   <li>हर structure institution और academic session के scope में सुरक्षित रहेगा।</li>
   <li>AI केवल authorized institutional/academic scope के अनुसार structure का उपयोग करेगा।</li>
  </ol></section>
  <footer>GBSBFORYOU School/OS · M6 Foundation · Institution manages its academic structure</footer>
 </main>
}
function Field({label,value,onChange,type='text',placeholder=''}){return <label>{label}<input type={type} value={value||''} placeholder={placeholder} onChange={e=>onChange(e.target.value)}/></label>}
function Select({label,value,onChange,options}){return <label>{label}<select value={value} onChange={e=>onChange(e.target.value)}>{options.map(o=><option key={o}>{o}</option>)}</select></label>}