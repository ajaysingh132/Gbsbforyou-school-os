 "use client";

import { useState } from "react";

const initial = {
  sessionName: "2026–27",
  startDate: "2026-04-01",
  endDate: "2027-03-31",
  term: "Annual",
  workingDays: "Monday–Saturday",
  holidays: "",
  exams: "",
  admissions: "",
  events: "",
  deadlines: ""
};

export default function Home() {
  const [data, setData] = useState(initial);
  const [saved, setSaved] = useState(false);

  const update = (key, value) => {
    setData((old) => ({ ...old, [key]: value }));
    setSaved(false);
  };

  const save = () => {
    localStorage.setItem(
      "gbsbforyou.institution.academic-calendar",
      JSON.stringify(data)
    );
    setSaved(true);
  };

  return (
    <main className="shell">
      <header className="topbar">
        <div>
          <small>GBSBFORYOU SCHOOL/OS</small>
          <h1>Academic Calendar</h1>
        </div>
        <span className="private">M2 • INSTITUTION SCOPE</span>
      </header>

      <section className="hero">
        <div>
          <span className="eyebrow">M2 — ACADEMIC SESSION & INSTITUTIONAL CALENDAR</span>
          <h2>{data.sessionName || "Academic Session"}</h2>
          <p>संस्था अपने academic time structure को स्वयं प्रबंधित करती है।</p>
        </div>
        <div className="sessionBadge">{data.term}</div>
      </section>

      <section className="policy">
        <div><b>Tenant</b><span>Institution scoped</span></div>
        <div><b>Session</b><span>{data.sessionName}</span></div>
        <div><b>Period</b><span>{data.startDate} → {data.endDate}</span></div>
        <div><b>Control</b><span>Institution</span></div>
      </section>

      <section className="card">
        <h3>Academic Session</h3>
        <div className="grid">
          <Field label="Session name" value={data.sessionName} onChange={(v)=>update("sessionName",v)} />
          <Field label="Term / Semester" value={data.term} onChange={(v)=>update("term",v)} />
          <Field label="Start date" type="date" value={data.startDate} onChange={(v)=>update("startDate",v)} />
          <Field label="End date" type="date" value={data.endDate} onChange={(v)=>update("endDate",v)} />
          <Field label="Working days" value={data.workingDays} onChange={(v)=>update("workingDays",v)} wide />
        </div>
      </section>

      <section className="card">
        <h3>Calendar Configuration</h3>
        <div className="grid">
          <Field label="Holidays" area value={data.holidays} onChange={(v)=>update("holidays",v)} />
          <Field label="Examination dates" area value={data.exams} onChange={(v)=>update("exams",v)} />
          <Field label="Admission / enrollment period" area value={data.admissions} onChange={(v)=>update("admissions",v)} />
          <Field label="Institutional events" area value={data.events} onChange={(v)=>update("events",v)} />
          <Field label="Important deadlines" area value={data.deadlines} onChange={(v)=>update("deadlines",v)} wide />
        </div>
        <button onClick={save}>Save Academic Calendar</button>
        {saved && <span className="saved">Calendar saved locally for this browser.</span>}
      </section>

      <footer>
        GBSBFORYOU School/OS • M2 Foundation • Calendar records remain within institution scope.
      </footer>
    </main>
  );
}

function Field({label, value, onChange, type="text", wide, area}) {
  return (
    <label className={wide ? "wide" : ""}>
      <span>{label}</span>
      {area ? (
        <textarea rows={4} value={value} onChange={(e)=>onChange(e.target.value)} />
      ) : (
        <input type={type} value={value} onChange={(e)=>onChange(e.target.value)} />
      )}
    </label>
  );
}