 "use client";

import { useState } from "react";

const initial = {
  name: "नया संस्थान",
  shortName: "",
  type: "School",
  logo: "",
  address: "",
  city: "",
  district: "",
  state: "",
  pin: "",
  phone: "",
  email: "",
  website: "",
  description: "",
  mission: "",
  vision: ""
};

export default function Home() {
  const [form, setForm] = useState(initial);
  const [saved, setSaved] = useState(false);

  function update(key, value) {
    setForm((old) => ({ ...old, [key]: value }));
    setSaved(false);
  }

  function save() {
    localStorage.setItem("gbsbforyou.institution.profile", JSON.stringify(form));
    setSaved(true);
  }

  return (
    <main className="shell">
      <header className="topbar">
        <div>
          <small>GBSBFORYOU SCHOOL/OS</small>
          <h1>Institution Workspace</h1>
        </div>
        <span className="private">PRIVATE • PROPRIETARY</span>
      </header>

      <section className="hero">
        <div>
          <span className="eyebrow">M1 — INSTITUTION PROFILE & BRANDING</span>
          <h2>{form.name || "आपका संस्थान"}</h2>
          <p>संस्था अपनी पहचान और profile data स्वयं नियंत्रित करती है।</p>
        </div>
        <div className="logoBox">
          {form.logo ? <img src={form.logo} alt="Institution logo" /> : "LOGO"}
        </div>
      </section>

      <section className="policy">
        <div><b>Software</b><span>GBSBFORYOU</span></div>
        <div><b>Institution Data</b><span>Institution controlled</span></div>
        <div><b>Tenant Scope</b><span>Isolated</span></div>
        <div><b>AI Scope</b><span>Authorized data only</span></div>
      </section>

      <section className="card">
        <h3>Institution Identity</h3>
        <div className="grid">
          <Field label="Institution name" value={form.name} onChange={(v)=>update("name",v)} />
          <Field label="Short name" value={form.shortName} onChange={(v)=>update("shortName",v)} />
          <Field label="Institution type" value={form.type} onChange={(v)=>update("type",v)} />
          <Field label="Logo URL" value={form.logo} onChange={(v)=>update("logo",v)} />
          <Field label="Address" value={form.address} onChange={(v)=>update("address",v)} wide />
          <Field label="City" value={form.city} onChange={(v)=>update("city",v)} />
          <Field label="District" value={form.district} onChange={(v)=>update("district",v)} />
          <Field label="State" value={form.state} onChange={(v)=>update("state",v)} />
          <Field label="PIN" value={form.pin} onChange={(v)=>update("pin",v)} />
          <Field label="Phone" value={form.phone} onChange={(v)=>update("phone",v)} />
          <Field label="Email" value={form.email} onChange={(v)=>update("email",v)} />
          <Field label="Website" value={form.website} onChange={(v)=>update("website",v)} />
        </div>
      </section>

      <section className="card">
        <h3>Institution Description</h3>
        <Field label="Description" value={form.description} onChange={(v)=>update("description",v)} area />
        <Field label="Mission" value={form.mission} onChange={(v)=>update("mission",v)} area />
        <Field label="Vision" value={form.vision} onChange={(v)=>update("vision",v)} area />
        <button onClick={save}>Save Institution Profile</button>
        {saved && <span className="saved">Profile saved locally for this browser.</span>}
      </section>

      <footer>
        GBSBFORYOU School/OS • M1 Foundation • Institutional data remains within institution scope.
      </footer>
    </main>
  );
}

function Field({label, value, onChange, wide, area}) {
  return (
    <label className={wide ? "wide" : ""}>
      <span>{label}</span>
      {area ? (
        <textarea value={value} onChange={(e)=>onChange(e.target.value)} rows={4} />
      ) : (
        <input value={value} onChange={(e)=>onChange(e.target.value)} />
      )}
    </label>
  );
}