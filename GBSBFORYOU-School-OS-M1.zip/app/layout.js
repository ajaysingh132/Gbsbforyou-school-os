import "./globals.css";

export const metadata = {
  title: "GBSBFORYOU School/OS",
  description: "Private institutional operating system by GBSBFORYOU"
};

export default function RootLayout({ children }) {
  return (
    <html lang="hi">
      <body>{children}</body>
    </html>
  );
}