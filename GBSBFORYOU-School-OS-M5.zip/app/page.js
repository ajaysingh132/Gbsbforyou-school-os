'use client';
import {useEffect,useState} from 'react';
import './globals.css';

const blank={guardianId:'',name:'',relationship:'Father',phone:'',altPhone:'',email:'',occupation:'',address:'',studentIds:'',primary:true,emergency:false,consent:true,notes:''};

export default function Page(){
 const [form,setForm]=useState(blank),[records,setRecords]=useState([]),[saved,setSaved]=useState(false);
 useEffect(()=>{try{setRecords(JSON.parse(localStorage.getItem('m5_guardians')||'[]'))}catch{}},[]);
 const set=(k,v)=>setForm({...form,[k]:v});
 function save(){
   if(!form.name.trim()) return;
   const id=form.guardianId||'GDN-'+Date.now().toString().slice(-8);
   const r={...form,guardianId:id,studentIds:form.studentIds.split(',').map(x=>x.trim()).filter(Boolean),updatedAt:new Date().toISOString()};
   const next=[...records.filter(x=>x.guardianId!==id),r];
   localStorage.setItem('m5_guardians',JSON.stringify(next));setRecords(next);setForm(r);setSaved(true);setTimeout(()=>setSaved(false),1600);
 }
 function edit(r){setForm({...r,studentIds:(r.studentIds||[]).join(', ')})}
 return <main>
  <header><div><div className="eyebrow">GBSBFORYOU SCHOOL/OS · M5</div><h1>Guardian / Family Management</h1><p>Student और उसके परिवार/अभिभावकों के बीच संरचित relationship record का आधार।</p></div><span className="badge">Relationship Scoped</span></header>
  <section className="hero">
   <div><small>MODULE</small><strong>Guardian & Family</strong></div><div><small>LINK KEY</small><strong>Student ID</strong></div><div><small>DATA OWNER</small><strong>Institution</strong></div><div><small>ACCESS</small><strong>Authorized Relationship</strong></div>
  </section>
  <section className="card"><h2>Guardian Profile</h2>
   <div className="formgrid">
    <Field label="Guardian ID" value={form.guardianId} onChange={v=>set('guardianId',v)} placeholder="खाली छोड़ें तो स्वतः बनेगा"/>
    <Field label="Name *" value={form.name} onChange={v=>set('name',v)}/>
    <Select label="Relationship" value={form.relationship} onChange={v=>set('relationship',v)} options={['Father','Mother','Guardian','Grandparent','Sibling','Other']}/>
    <Field label="Primary Phone" value={form.phone} onChange={v=>set('phone',v)} type="tel"/>
    <Field label="Alternate Phone" value={form.altPhone} onChange={v=>set('altPhone',v)} type="tel"/>
    <Field label="Email" value={form.email} onChange={v=>set('email',v)} type="email"/>
    <Field label="Occupation" value={form.occupation} onChange={v=>set('occupation',v)}/>
    <Field label="Linked Student ID(s)" value={Array.isArray(form.studentIds)?form.studentIds.join(', '):form.studentIds} onChange={v=>set('studentIds',v)} placeholder="उदा. STU-1234, STU-5678"/>
   </div>
   <label>Address<textarea value={form.address||''} onChange={e=>set('address',e.target.value)}/></label>
   <label>Notes<textarea value={form.notes||''} onChange={e=>set('notes',e.target.value)}/></label>
   <div className="toggles">
    <label><input type="checkbox" checked={!!form.primary} onChange={e=>set('primary',e.target.checked)}/> Primary Guardian</label>
    <label><input type="checkbox" checked={!!form.emergency} onChange={e=>set('emergency',e.target.checked)}/> Emergency Contact</label>
    <label><input type="checkbox" checked={!!form.consent} onChange={e=>set('consent',e.target.checked)}/> Communication Consent</label>
   </div>
  </section>
  <section className="actions"><button onClick={save}>Save Guardian Record</button><button className="secondary" onClick={()=>setForm(blank)}>New Guardian</button>{saved&&<span className="success">रिकॉर्ड सुरक्षित ✓</span>}</section>
  <section className="grid two">
   <article className="card"><h2>Relationship Model</h2><div className="diagram"><span>Guardian</span><b>↔</b><span>Family Relationship</span><b>↔</b><span>Student ID</span></div><p className="note">एक Guardian कई students से और एक student कई authorized guardians से जुड़ सकता है।</p></article>
   <article className="card"><h2>Access Boundary</h2><ul className="checks"><li>✓ Institution scoped</li><li>✓ Relationship scoped</li><li>✓ Student-linked access</li><li>✓ Consent-aware communication</li><li>✓ Audit-ready changes</li><li>✓ AI authorized-scope only</li></ul></article>
  </section>
  <section className="card"><h2>Saved Guardians — Prototype</h2>
   {records.length===0?<p className="note">अभी कोई स्थानीय prototype record नहीं है।</p>:
   <div className="table"><div className="tr th"><span>Guardian</span><span>Relationship</span><span>Student IDs</span><span>Flags</span></div>
   {records.map(r=><div className="tr" key={r.guardianId}><span><b>{r.name}</b><small>{r.guardianId}</small></span><span>{r.relationship}</span><span>{(r.studentIds||[]).join(', ')||'—'}</span><span>{r.primary?'Primary ':''}{r.emergency?'Emergency':''}</span><button className="tiny" onClick={()=>edit(r)}>Edit</button></div>)}</div>}
  </section>
  <section className="card policy"><h2>M5 Governance Rules</h2><ol>
   <li>M4 Student Master Record छात्र की मूल identity का source-of-truth रहेगा।</li>
   <li>M5 guardian/family relationship का source-of-truth रहेगा।</li>
   <li>Guardian access केवल authorized institution + relationship + scope से निर्धारित होगा।</li>
   <li>एक institution का guardian दूसरे institution के operational records तक नहीं पहुँच सकता।</li>
   <li>Communication consent और emergency-contact status को explicit records माना जाएगा।</li>
   <li>AI guardian data पर केवल अधिकृत scope और policy के अनुसार कार्य करेगा।</li>
  </ol></section>
  <footer>GBSBFORYOU School/OS · M5 Foundation · Institution manages its own family data</footer>
 </main>
}
function Field({label,value,onChange,type='text',placeholder=''}){return <label>{label}<input type={type} value={value||''} placeholder={placeholder} onChange={e=>onChange(e.target.value)}/></label>}
function Select({label,value,onChange,options}){return <label>{label}<select value={value} onChange={e=>onChange(e.target.value)}>{options.map(o=><option key={o}>{o}</option>)}</select></label>}