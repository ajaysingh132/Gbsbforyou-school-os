 "use client";
import {useEffect,useState} from "react";
import "./style.css";

const modules=[
["⌂","संस्थान","Institution identity, address & branding"],["◷","डिजिटल रोज़नामा","Daily institutional record"],["🤖","AI Manager","Tasks, monitoring & evening report"],["✓","Tasks / Approvals","Central workflow"],["👥","विद्यार्थी","Student information"],["◫","उपस्थिति","Attendance & presence"],["📚","शैक्षणिक","Classes, subjects & curriculum"],["🗓","टाइमटेबल","Scheduling"],["📝","परीक्षा","Examination & results"],["📊","रिपोर्ट कार्ड","Progress & report cards"],["👨‍🏫","Teacher / Staff","Academic & HR"],["₹","Finance","Fees, income & expenditure"],["🚌","Transport","Routes & student safety"],["🏫","Campus / Assets","Infrastructure & inventory"],["▣","Meetings / Budget / Tax","Decisions & finance planning"],["✉","Communication","Institutional messaging"],["📄","Documents","Digital document vault"],["⚖","Compliance","Inspection & regulatory reports"],["👨‍👩‍👧","Parent Portal","Student/parent access"],["📈","Analytics","Institutional intelligence"],["☁","Cloud Memory","Institutional memory"],["↻","Backup / Sync","Continuity & recovery"],["🔐","Security","Identity, permissions & audit"]
];

const demo={
"संस्थान":{title:"Institution Identity & Branding",desc:"यह संस्था अपने नाम, पते, विवरण और branding को स्वयं नियंत्रित करती है.",cards:["संस्था का नाम","पूरा पता","Principal / Head","Logo & Brand","Vision / Mission","Contact & Website"]},
"डिजिटल रोज़नामा":{title:"Digital Roznamcha",desc:"एक दिन — एक संस्थागत रोज़नामा — अनेक structured records से जुड़ा हुआ.",cards:["आज की entries","Voice / Text Entry","Pending confirmation","Linked records","Daily closure","Audit trail"]},
"AI Manager":{title:"AI Manager",desc:"AI केवल अधिकृत data से plan, summarize, remind और recommend करता है.",cards:["Morning Plan","Staff Work","Progress Monitor","Exceptions","Evening Report","Tomorrow Plan"]},
"Tasks / Approvals":{title:"Central Workflow & Approvals",desc:"Request → Review → Decision → Action → Verification → Closure.",cards:["My Tasks","My Approvals","Evidence Required","Escalations","Resubmission","Audit History"]},
"विद्यार्थी":{title:"Student Information System",desc:"Session-wise student identity और longitudinal institutional record.",cards:["Student Profiles","Admission","Family Link","Class / Section","Documents","History"]},
"उपस्थिति":{title:"Attendance & Presence",desc:"Identity + Device + Time + Location + Schedule + Evidence.",cards:["Today Attendance","Verification","Exceptions","Corrections","Offline Queue","Audit"]},
"शैक्षणिक":{title:"Academic Structure",desc:"Classes, sections, subjects, curriculum और learning outcomes.",cards:["Classes","Sections","Subjects","Curriculum","Learning Outcomes","Academic Programs"]},
"टाइमटेबल":{title:"Timetable & Scheduling",desc:"Teacher, room, class और activity conflicts की जांच.",cards:["Today's Timetable","Teacher Schedule","Rooms","Conflicts","Substitution","Calendar"]},
"परीक्षा":{title:"Examination Management",desc:"Schedule → Eligibility → Exam → Marks → Verification → Result.",cards:["Exam Schedule","Question Bank","Attendance","Marks","Moderation","Results"]},
"रिपोर्ट कार्ड":{title:"Report Card & Progress",desc:"Approved academic evidence से session-wise progress.",cards:["Report Cards","Subject Progress","Competencies","Remarks","Promotion","Publication"]},
"Teacher / Staff":{title:"Teacher & Staff Management",desc:"Role, assignment, scope, attendance और HR records.",cards:["Staff Directory","Assignments","Leave","Attendance","Documents","HR History"]},
"Finance":{title:"Fees & Finance",desc:"Demand → Payment → Receipt → Outstanding → Expense → Audit.",cards:["Fee Structure","Payments","Outstanding","Expenses","Budget","Financial Audit"]},
"Transport":{title:"Transport & Student Safety",desc:"Routes, trips, boarding, drop-off और safety evidence.",cards:["Vehicles","Routes","Trips","Boarding","Authorized Pickup","Incidents"]},
"Campus / Assets":{title:"Campus & Assets",desc:"Campus → Room → Asset → Maintenance → Inspection.",cards:["Campus","Rooms","Assets","Inventory","Maintenance","Safety"]},
"Meetings / Budget / Tax":{title:"Meetings, Budget & Tax",desc:"Decisions और financial planning एक controlled workflow में.",cards:["Meetings","Minutes","Actions","Budget","Income / Expenditure","Tax Calendar"]},
"Communication":{title:"Institutional Communication",desc:"सही सूचना + सही व्यक्ति + सही समय + सही अधिकार + delivery history.",cards:["Announcements","Staff Messages","Parents","Acknowledgement","Emergency","History"]},
"Documents":{title:"Digital Document Vault",desc:"Versioned, permission-controlled institutional records.",cards:["All Documents","Upload / Scan","Versions","Approvals","Expiry","Archive"]},
"Compliance":{title:"Inspection & Compliance",desc:"Requirement → Evidence → Verification → Decision → Audit.",cards:["Requirements","Evidence Gaps","Inspections","Corrective Actions","ATR Reports","Submissions"]},
"Parent Portal":{title:"Student & Parent Portal",desc:"Relationship-based access; official records सीधे edit नहीं होते.",cards:["Children","Attendance","Academics","Fees","Transport","Requests"]},
"Analytics":{title:"Institutional Analytics",desc:"M1–M25 से role-scoped decision intelligence.",cards:["Academic","Attendance","Finance","Assets","Compliance","Data Quality"]},
"Cloud Memory":{title:"Institutional Cloud Memory",desc:"Operational, Institutional और Archive Memory — provider independent.",cards:["Operational Memory","Institutional Memory","Archive","Sync Status","Retention","Access Audit"]},
"Backup / Sync":{title:"Backup, Sync & Recovery",desc:"Local-first continuity with verified backup and conflict protection.",cards:["Sync Queue","Conflicts","Backups","Verification","Recovery Points","Server Health"]},
"Security":{title:"Identity, Permissions & Audit",desc:"RBAC + Relationship + Scope + Policy + Audit.",cards:["Users","Roles","Scopes","Sessions","Security Events","Audit Logs"]}
};

function App(){
 const [active,setActive]=useState("संस्थान");
 const [institution,setInstitution]=useState({name:"अपना संस्थान दर्ज करें",address:"पता दर्ज करें",desc:"संस्था का परिचय यहां लिखें",logo:""});
 const [edit,setEdit]=useState(false);
 const [online,setOnline]=useState(true);
 useEffect(()=>{setOnline(navigator.onLine);const a=()=>setOnline(true),b=()=>setOnline(false);addEventListener("online",a);addEventListener("offline",b);return()=>{removeEventListener("online",a);removeEventListener("offline",b)}},[]);
 const m=demo[active]||demo["संस्थान"];
 return <div className="app">
  <aside><div className="logo">GBSBFORYOU<span>School/OS</span></div><div className="platform">CORE INSTITUTIONAL SOFTWARE</div><nav>{modules.map(([ic,n])=><button className={active===n?"sel":""} onClick={()=>setActive(n)} key={n}><i>{ic}</i>{n}</button>)}</nav></aside>
  <main>
   <header><div><h1>{active}</h1><p>GBSBFORYOU School/OS • {institution.name}</p></div><div className="head-actions"><span className={online?"ok":"off"}>● {online?"Local / Online":"Offline"}</span><button>☁ Sync</button><button>▣ Report</button></div></header>
   <section className="identity">
    <div className="brandbox">{institution.logo?<img src={institution.logo}/>:<div className="logo-placeholder">LOGO</div>}<div><h2>{institution.name}</h2><p>{institution.address}</p><p>{institution.desc}</p></div></div>
    <button onClick={()=>setEdit(!edit)} className="primary">{edit?"Save Profile":"Edit Institution Profile"}</button>
   </section>
   {edit&&<section className="editor">
    <input value={institution.name} onChange={e=>setInstitution({...institution,name:e.target.value})} placeholder="Institution Name"/>
    <input value={institution.address} onChange={e=>setInstitution({...institution,address:e.target.value})} placeholder="Full Address"/>
    <input value={institution.desc} onChange={e=>setInstitution({...institution,desc:e.target.value})} placeholder="Description"/>
    <input value={institution.logo} onChange={e=>setInstitution({...institution,logo:e.target.value})} placeholder="Logo image URL (optional)"/>
   </section>}
   <section className="stats">{[["विद्यार्थी","1,248"],["Staff","86"],["Classes","36"],["Today's Attendance","94.6%"],["Pending Approvals","7"],["Compliance","91%"]].map(x=><div className="stat" key={x[0]}><small>{x[0]}</small><strong>{x[1]}</strong></div>)}</section>
   <section className="workspace"><div className="card maincard"><h3>{m.title}</h3><p className="desc">{m.desc}</p><div className="cards">{m.cards.map((c,i)=><button className="tile" key={c} onClick={()=>alert(c+" — module workspace")}><b>{["01","02","03","04","05","06"][i]}</b><span>{c}</span><em>Open ›</em></button>)}</div></div>
   <div className="card"><h3>Institution Control</h3><div className="line"><span>Data Ownership</span><b>Institute</b></div><div className="line"><span>Platform Updates</span><b>GBSBFORYOU</b></div><div className="line"><span>AI Data Scope</span><b>Authorized only</b></div><div className="line"><span>Audit</span><b>Enabled</b></div><div className="line"><span>Cloud Provider</span><b>Configurable</b></div></div></section>
   <footer>GBSBFORYOU School/OS v1.0 • Institution data remains institution-controlled • AI recommendations and official/high-impact actions remain approval-controlled.</footer>
  </main>
  <div className="mobile-nav">{modules.slice(0,5).map(([ic,n])=><button onClick={()=>setActive(n)} key={n}>{ic}<small>{n}</small></button>)}</div>
 </div>
}
export default App;
