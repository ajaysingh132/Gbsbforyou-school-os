export const metadata = {
  title: "GBSBFORYOU School/OS — M3",
  description: "Identity, Users, Roles & Permissions foundation"
};
export default function RootLayout({ children }) {
  return <html lang="hi"><body>{children}</body></html>;
}