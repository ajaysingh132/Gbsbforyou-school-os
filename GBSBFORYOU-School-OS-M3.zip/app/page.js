'use client';
import { useEffect, useState } from 'react';
import './globals.css';

const roles = [
  ['Platform Admin','GBSBFORYOU platform','Platform-level'],
  ['Institution Administrator','Institution','Institution'],
  ['Principal / Head','Institution','Institution'],
  ['Teacher','Class / Subject','Scoped'],
  ['Non-Teaching Staff','Department / assigned scope','Scoped'],
  ['Accountant','Finance','Module-scoped'],
  ['Librarian','Library','Module-scoped'],
  ['Transport Manager','Transport','Module-scoped'],
  ['Parent / Guardian','Linked student','Relationship-scoped'],
  ['Student','Self / permitted academic data','Individual-scoped']
];

const permissions = [
  ['View','रिकॉर्ड देखना'],
  ['Create','नया रिकॉर्ड बनाना'],
  ['Update','रिकॉर्ड संशोधित करना'],
  ['Approve','अनुमोदन करना'],
  ['Export','अनुमत डेटा निर्यात करना'],
  ['Manage Users','उपयोगकर्ता/भूमिका प्रबंधन'],
  ['Manage Permissions','अधिकार बदलना']
];

export default function Page() {
  const [institution, setInstitution] = useState('My Institution');
  const [userName, setUserName] = useState('');
  const [role, setRole] = useState('Institution Administrator');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setInstitution(localStorage.getItem('m1_institution_name') || 'My Institution');
    setUserName(localStorage.getItem('m3_user_name') || '');
    setRole(localStorage.getItem('m3_role') || 'Institution Administrator');
  }, []);

  function save() {
    localStorage.setItem('m3_user_name', userName);
    localStorage.setItem('m3_role', role);
    setSaved(true);
    setTimeout(() => setSaved(false), 1800);
  }

  return (
    <main>
      <header>
        <div>
          <div className="eyebrow">GBSBFORYOU SCHOOL/OS · M3</div>
          <h1>Identity, Users, Roles & Permissions</h1>
          <p>हर उपयोगकर्ता को उसकी संस्था, भूमिका, संबंध और अनुमत Scope के अनुसार नियंत्रित करने का आधार।</p>
        </div>
        <span className="badge">Deny by Default</span>
      </header>

      <section className="hero">
        <div><small>ACTIVE INSTITUTION</small><strong>{institution}</strong></div>
        <div><small>DATA OWNER</small><strong>Institution</strong></div>
        <div><small>PLATFORM</small><strong>GBSBFORYOU</strong></div>
        <div><small>AI ACCESS</small><strong>Authorized Scope Only</strong></div>
      </section>

      <section className="grid two">
        <article className="card">
          <h2>User Identity Foundation</h2>
          <label>User display name<input value={userName} onChange={e=>setUserName(e.target.value)} placeholder="उदा. प्रधानाचार्य" /></label>
          <label>Role<select value={role} onChange={e=>setRole(e.target.value)}>{roles.map(r=><option key={r[0]}>{r[0]}</option>)}</select></label>
          <button onClick={save}>Save Identity Foundation</button>
          {saved && <div className="success">स्थानीय रूप से सुरक्षित ✓</div>}
          <p className="note">यह M3 prototype UI है। Production में server-side authentication, secure sessions और database persistence जोड़ी जाएगी।</p>
        </article>

        <article className="card">
          <h2>Security Boundary</h2>
          <ul className="checks">
            <li>✓ Institution isolation</li>
            <li>✓ Scope-based authorization</li>
            <li>✓ Relationship-based access</li>
            <li>✓ RBAC foundation</li>
            <li>✓ Audit-ready permission changes</li>
            <li>✓ AI authorization boundary</li>
          </ul>
        </article>
      </section>

      <section className="card">
        <h2>Role Catalogue</h2>
        <div className="table">
          <div className="tr th"><span>Role</span><span>Primary Scope</span><span>Access Model</span></div>
          {roles.map(r=><div className="tr" key={r[0]}><span>{r[0]}</span><span>{r[1]}</span><span>{r[2]}</span></div>)}
        </div>
      </section>

      <section className="grid two">
        <article className="card">
          <h2>Permission Model</h2>
          <div className="permission-list">
            {permissions.map(p=><div key={p[0]}><b>{p[0]}</b><span>{p[1]}</span></div>)}
          </div>
        </article>
        <article className="card">
          <h2>Authorization Scope</h2>
          <div className="scope">
            <span>Institution</span><i>→</i><span>Campus</span><i>→</i><span>Department</span><i>→</i>
            <span>Program</span><i>→</i><span>Class</span><i>→</i><span>Section</span><i>→</i>
            <span>Subject</span><i>→</i><span>Individual Record</span>
          </div>
          <p className="note">किसी अनुमति को Scope से बाहर स्वतः विस्तारित नहीं किया जाएगा।</p>
        </article>
      </section>

      <section className="card policy">
        <h2>Core Governance Rules</h2>
        <ol>
          <li>Authentication और authorization अलग लेकिन जुड़े हुए layers हैं।</li>
          <li>हर request पर institution और scope की जाँच होगी।</li>
          <li>Default स्थिति: access denied; केवल स्पष्ट permission पर access granted।</li>
          <li>एक institution का user दूसरे institution के operational data तक नहीं पहुँच सकता।</li>
          <li>Permission changes, login/access events और sensitive actions audit-ready रहेंगे।</li>
          <li>AI केवल उसी data scope पर कार्य करेगा जिसकी user/system policy अनुमति देती है।</li>
        </ol>
      </section>

      <footer>GBSBFORYOU School/OS · M3 Foundation · Software updates by GBSBFORYOU · Institution manages its own data</footer>
    </main>
  );
}